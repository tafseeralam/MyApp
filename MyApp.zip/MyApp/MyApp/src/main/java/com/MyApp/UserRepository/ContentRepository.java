package com.MyApp.UserRepository;

import java.util.List;

import javax.swing.text.AbstractDocument.Content;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ContentRepository extends JpaRepository<Content, Long> {
    List<Content> findByCategory(String category);
} 


