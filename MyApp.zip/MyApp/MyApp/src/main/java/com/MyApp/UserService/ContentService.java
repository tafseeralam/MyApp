package com.MyApp.UserService;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.WebProperties.Resources.Chain.Strategy.Content;
import org.springframework.stereotype.Service;

import com.MyApp.ContentRepository.ContentRepository;

@Service
	public class ContentService {

	    @Autowired
	    private ContentRepository contentRepositoryRepository;

	    public List<String> getAllCategories() {
	        List<String> categories = new ArrayList<>();
	        List<Content> contentList = contentRepositoryRepository.findAll();

	        // Extract unique categories from content
	        contentList.forEach(content -> {
	            if (!categories.contains(content.getCategory())) {
	                categories.add(content.getCategory());
	            }
	        });

	        return categories;
	    }

	    // Other content-related methods as needed
	}


}
