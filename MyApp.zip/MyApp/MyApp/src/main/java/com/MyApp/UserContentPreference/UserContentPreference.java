package com.MyApp.UserContentPreference;

import org.springframework.boot.autoconfigure.web.WebProperties.Resources.Chain.Strategy.Content;
import org.springframework.data.annotation.Id;

import com.MyApp.User.User;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
	public class UserContentPreference {
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    @ManyToOne
	    @JoinColumn(name = "user_id")
	    private User user;

	    @ManyToOne
	    @JoinColumn(name = "content_id")
	    private Content content;

		public UserContentPreference(Long id, User user, Content content) {
			super();
			this.id = id;
			this.user = user;
			this.content = content;
		}

		@Override
		public String toString() {
			return "UserContentPreference [id=" + id + ", user=" + user + ", content=" + content + "]";
		}

		public UserContentPreference() {
			super();
			this.id = id;
			this.user = user;
			this.content = content;
		}

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public User getUser() {
			return user;
		}

		public void setUser(User user) {
			this.user = user;
		}

		public Content getContent() {
			return content;
		}

		public void setContent(Content content2) {
			this.content = content2;
		}

		public void setContent(User content2) {
			// TODO Auto-generated method stub
			
		}
	    

	    // Other preference-related fields, getters, and setters
	}


