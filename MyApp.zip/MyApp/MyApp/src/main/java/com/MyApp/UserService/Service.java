package com.MyApp.UserService;

import org.springframework.beans.factory.annotation.Autowired;

import com.MyApp.User.User;
import com.MyApp.UserRepository.UserRepository;

public class Service {
	
	public class UserService {

	    @Autowired
	    private UserRepository userRepository;

	    public void registerUser(User user) {
	        // Additional validation and business logic can be added here
	        userRepository.save(user);
	    }

	    // Other user-related methods as needed
	}


}
