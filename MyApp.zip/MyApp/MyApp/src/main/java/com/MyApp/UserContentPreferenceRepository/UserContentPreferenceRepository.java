package com.MyApp.UserContentPreferenceRepository;

import com.MyApp.User.User;
import com.MyApp.UserContentPreference.UserContentPreference;

import com.zaxxer.hikari.util.FastList;

public interface UserContentPreferenceRepository {

	FastList<UserContentPreference> findByUser(User user);

	boolean existsByUserAndContent1(User user, User content);

	void save1(UserContentPreference userContentPreference);

	void save(UserContentPreference userContentPreference);

	boolean existsByUserAndContent(User user, User content);

}
