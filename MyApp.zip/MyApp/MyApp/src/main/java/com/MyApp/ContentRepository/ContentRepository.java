package com.MyApp.ContentRepository;

import java.util.List;
import java.util.Optional;

import org.springframework.boot.autoconfigure.web.WebProperties.Resources.Chain.Strategy.Content;

import com.MyApp.User.User;

public interface ContentRepository {

	Optional<User> findById(Long contentId);

	List<Content> findAll();

}
