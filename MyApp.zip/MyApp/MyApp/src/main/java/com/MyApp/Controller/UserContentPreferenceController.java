package com.MyApp.Controller;

public class UserContentPreferenceController {
	@RestController
	@RequestMapping("/api/user-content-preferences")
	public class UserContentPreferenceController {

	    @Autowired
	    private UserContentPreferenceService userContentPreferenceService;

	    @PostMapping("/subscribe")
	    public ResponseEntity<String> subscribeToContent(
	            @RequestParam Long userId,
	            @RequestParam Long contentId) {
	        userContentPreferenceService.subscribeUserToContent(userId, contentId);
	        return ResponseEntity.ok("User subscribed to content successfully");
	    }

	    @GetMapping("/user/{userId}")
	    public ResponseEntity<List<Content>> getUserSubscriptions(@PathVariable Long userId) {
	        List<Content> userSubscriptions = userContentPreferenceService.getUserSubscriptions(userId);
	        return ResponseEntity.ok(userSubscriptions);
	    }

	    // Other user content preference-related endpoints as needed
	}


}
