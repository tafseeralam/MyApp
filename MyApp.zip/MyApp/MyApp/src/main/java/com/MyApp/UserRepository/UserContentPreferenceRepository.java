package com.MyApp.UserRepository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.MyApp.User.User;
import com.MyApp.UserContentPreference.UserContentPreference;

public interface UserContentPreferenceRepository extends JpaRepository<UserContentPreference, Long> {
    List<UserContentPreference> findByUser(User user);
}


