package com.MyApp.UserService;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.WebProperties.Resources.Chain.Strategy.Content;
import org.springframework.stereotype.Service;

import com.MyApp.ContentRepository.ContentRepository;
import com.MyApp.User.User;
import com.MyApp.UserContentPreference.UserContentPreference;
import com.MyApp.UserContentPreferenceRepository.UserContentPreferenceRepository;
import com.MyApp.UserRepository.UserRepository;

import jakarta.persistence.EntityNotFoundException;

      @Service
	public class UserContentPreferenceService {
		

	    @Autowired
	    private UserContentPreferenceRepository userContentPreferenceRepository;

	    @Autowired
	    private UserRepository userRepository;

	    @Autowired
	    private ContentRepository contentRepository;

	    public void subscribeUserToContent(Long userId, Long contentId) {
	        // Check if user and content exist
	        User user = userRepository.findById(userId)
	                .orElseThrow(() -> new EntityNotFoundException("User not found with id: " + userId));

	        User content = contentRepository.findById(contentId)
	                .orElseThrow(() -> new EntityNotFoundException("Content not found with id: " + contentId));

	        // Check if the user is already subscribed to the content
	        if (userContentPreferenceRepository.existsByUserAndContent(user, content)) {
	            throw new RuntimeException("User is already subscribed to this content");
	        }

	        // Subscribe the user to the content
	        UserContentPreference userContentPreference = new UserContentPreference();
	        userContentPreference.setUser(user);
	        userContentPreference.setContent(content);

	        userContentPreferenceRepository.save(userContentPreference);
	    }

	    public List<Content> getUserSubscriptions(Long userId) {
	        User user = userRepository.findById(userId)
	                .orElseThrow(() -> new EntityNotFoundException("User not found with id: " + userId));

	        List<UserContentPreference> userContentPreferences = userContentPreferenceRepository.findByUser(user);

	        return userContentPreferences.stream()
	                .map(UserContentPreference::getContent)
	                .collect(Collectors.toList());
	    }

	    // Other user content preference-related methods as needed
	}



