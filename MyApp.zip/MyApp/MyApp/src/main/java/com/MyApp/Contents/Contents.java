package com.MyApp.Contents;

import org.hibernate.annotations.Table;
import org.springframework.data.annotation.Id;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;


	@Entity
	
	public class Contents {
		
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    private String title;
	    private String category;
	    
		@Override
		public String toString() {
			return "Content [id=" + id + ", title=" + title + ", category=" + category + "]";
		}
		public Contents(Long id, String title, String category) {
			super();
			this.id = id;
			this.title = title;
			this.category = category;
		}
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public String getCategory() {
			return category;
		}
		public void setCategory(String category) {
			this.category = category;
		}

	    // Other content-related fields, getters, and setters
	    
	}


