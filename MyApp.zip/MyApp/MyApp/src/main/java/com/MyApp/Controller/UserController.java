package com.MyApp.Controller;

public class UserController {
	@RestController
	@RequestMapping("/api/users")
	public class UserController {
	    
	    @Autowired
	    private UserService userService;

	    @PostMapping("/register")
	    public ResponseEntity<String> registerUser(@RequestBody User user) {
	        userService.registerUser(user);
	        return ResponseEntity.ok("User registered successfully");
	    }

	    // Other user-related endpoints as needed
	}


}
