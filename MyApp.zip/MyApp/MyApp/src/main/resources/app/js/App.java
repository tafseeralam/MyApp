package app.js;

public class App {
	import React, { useState, useEffect } from 'react';
	import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
	import HomePage from './components/HomePage';
	import UserPreferencesPage from './components/UserPreferencesPage';
	import NotificationSubscriptionPage from './components/NotificationSubscriptionPage';

	function App() {
	  return (
	    <Router>
	      <div className="app">
	        <Switch>
	          <Route path="/" exact component={HomePage} />
	          <Route path="/preferences" component={UserPreferencesPage} />
	          <Route path="/subscription" component={NotificationSubscriptionPage} />
	        </Switch>
	      </div>
	    </Router>
	  );
	}

	export default App;

}
