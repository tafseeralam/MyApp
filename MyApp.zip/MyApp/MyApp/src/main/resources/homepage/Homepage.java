package homepage;

public class Homepage {
	import React from 'react';
	import { Link } from 'react-router-dom';

	function HomePage() {
	  return (
	    <div>
	      <h1>Welcome to the Notification App</h1>
	      <p>Select your preferences to receive personalized notifications.</p>
	      <Link to="/preferences">Choose Preferences</Link>
	    </div>
	  );
	}

	export default HomePage;


}
