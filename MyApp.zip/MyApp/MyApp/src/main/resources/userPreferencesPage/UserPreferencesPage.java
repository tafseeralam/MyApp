package userPreferencesPage;

public class UserPreferencesPage {
	import React, { useState, useEffect } from 'react';
	import axios from 'axios';

	function UserPreferencesPage() {
	  const [categories, setCategories] = useState([]);

	  useEffect(() => {
	    // Fetch categories from the backend
	    axios.get('/api/content/categories')
	      .then(response => setCategories(response.data))
	      .catch(error => console.error('Error fetching categories:', error));
	  }, []);

	  return (
	    <div>
	      <h2>Select Your Preferences</h2>
	      <ul>
	        {categories.map(category => (
	          <li key={category}>{category}</li>
	        ))}
	      </ul>
	      {/* Implement logic for user to select preferences */}
	      <button>Save Preferences</button>
	      <br />
	      <Link to="/subscription">Subscribe to Notifications</Link>
	    </div>
	  );
	}

	export default UserPreferencesPage;


}
